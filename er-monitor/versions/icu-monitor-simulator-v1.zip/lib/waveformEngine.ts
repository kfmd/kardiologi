import { RhythmType, WaveformSettings } from "@/types/monitor";
import { rhythmTemplates, BeatPoint } from "./ecgTemplates";

/**
 * Resamples a normalized beat template into pixel-domain points for one beat,
 * given the beat duration in samples, gain, and noise/artifact settings.
 */
export function generateBeatSamples(
  rhythm: RhythmType,
  beatDurationSamples: number,
  gain: number
): number[] {
  const template = rhythmTemplates[rhythm];
  const samples: number[] = new Array(beatDurationSamples).fill(0);

  for (let i = 0; i < beatDurationSamples; i++) {
    const x = i / beatDurationSamples;
    samples[i] = interpolateTemplate(template, x) * gain;
  }
  return samples;
}

function interpolateTemplate(template: BeatPoint[], x: number): number {
  for (let i = 0; i < template.length - 1; i++) {
    const [x0, y0] = template[i];
    const [x1, y1] = template[i + 1];
    if (x >= x0 && x <= x1) {
      const t = x1 === x0 ? 0 : (x - x0) / (x1 - x0);
      return y0 + (y1 - y0) * t;
    }
  }
  return 0;
}

/** Adds gaussian-ish noise + baseline wander to a sample buffer, in place logic returned as new array */
export function applyArtifacts(
  samples: number[],
  settings: WaveformSettings,
  tOffset: number
): number[] {
  return samples.map((v, i) => {
    let out = v;
    if (settings.noiseLevel > 0) {
      out += (Math.random() - 0.5) * settings.noiseLevel * 0.15;
    }
    if (settings.baselineWander > 0) {
      out += Math.sin((tOffset + i) * 0.01) * settings.baselineWander * 0.2;
    }
    if (settings.artifactLevel > 0 && Math.random() < settings.artifactLevel * 0.01) {
      out += (Math.random() - 0.5) * 1.5;
    }
    return out;
  });
}

/** Beat duration in samples based on HR and sample rate */
export function beatDurationFromHR(hr: number, sampleRate: number): number {
  const bpm = Math.max(hr, 1);
  const secondsPerBeat = 60 / bpm;
  return Math.round(secondsPerBeat * sampleRate);
}

/** Generates a pleth pulse shaped by amplitude & perfusion index */
export function generatePlethBeat(
  beatDurationSamples: number,
  amplitude: number,
  perfusionIndex: number
): number[] {
  const samples: number[] = new Array(beatDurationSamples).fill(0);
  const pi = Math.max(0.1, Math.min(perfusionIndex, 10)) / 10;
  for (let i = 0; i < beatDurationSamples; i++) {
    const x = i / beatDurationSamples;
    const rise = Math.pow(Math.sin(Math.PI * Math.min(x / 0.3, 1)), 2);
    const fall = x > 0.3 ? Math.exp(-((x - 0.3) * 4)) : 0;
    const val = (x < 0.3 ? rise : fall) * amplitude * (0.4 + pi * 0.6);
    samples[i] = val;
  }
  return samples;
}

/** Generates a respiration sine wave segment */
export function generateRespSamples(
  numSamples: number,
  rr: number,
  amplitude: number,
  sampleRate: number
): number[] {
  const cyclesPerSample = rr / 60 / sampleRate;
  const samples: number[] = new Array(numSamples).fill(0);
  for (let i = 0; i < numSamples; i++) {
    samples[i] = Math.sin(2 * Math.PI * cyclesPerSample * i) * amplitude;
  }
  return samples;
}

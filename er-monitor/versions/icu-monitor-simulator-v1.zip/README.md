# ICU / ER Patient Monitor Simulator

Educational bedside patient monitor simulator (Mindray ePM / Philips IntelliVue style)
for ACLS, ATLS, PALS, and critical care training. NOT for clinical use.

## Setup

```bash
npm install
npm run dev
```

Open:
- http://localhost:3000/monitor — Student Monitor Display
- http://localhost:3000/admin — Instructor Login (password: instructor123)

## Structure

- `app/monitor` — Student-facing read-only monitor display
- `app/admin` — Instructor login + `/admin/dashboard` control panel
- `components/Monitor` — ECGWave, PlethWave, RespWave, VitalCard, PatientHeader, TrendTable, AlarmBanner, SoftButtons
- `components/Admin` — VitalControls, WaveformControls, AlarmControls, ScenarioBuilder, LivePreview
- `store/useMonitorStore.ts` — Zustand global state shared between monitor and admin (V1, swappable for WebSocket/Supabase Realtime later)
- `store/useAuthStore.ts` — Simple instructor login gate
- `lib/ecgTemplates.ts` — Normalized beat morphology templates for 16 ECG rhythms
- `lib/waveformEngine.ts` — Beat resampling, artifact injection, pleth/resp generators
- `lib/alarmEngine.ts` — Physiological + technical alarm evaluation
- `hooks/useKeyboardShortcuts.ts` — Space (pause/resume), R (restart), A (silence alarms), F (fullscreen)
- `types/monitor.ts` — Core TypeScript data model

## Keyboard Shortcuts (on Monitor page)

- Space: Pause/Resume scenario
- R: Restart scenario
- A: Toggle alarm silence
- F: Toggle fullscreen

## Notes

- Change instructor password in `store/useAuthStore.ts` (`ADMIN_PASSWORD`).
- Bigeminy/Trigeminy rhythms currently reuse the NSR template; inject `pvcBeat` every 2nd/3rd beat in `waveformEngine.ts` for full fidelity.
- Architecture keeps all cross-view state in Zustand so WebSocket/Supabase Realtime sync can be added later without refactoring components.

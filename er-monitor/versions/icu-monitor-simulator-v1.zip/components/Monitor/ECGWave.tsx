"use client";

import { useEffect, useRef } from "react";
import { useMonitorStore } from "@/store/useMonitorStore";
import { generateBeatSamples, applyArtifacts, beatDurationFromHR } from "@/lib/waveformEngine";

const SAMPLE_RATE = 100; // samples per second
const WIDTH = 800;
const HEIGHT = 120;

export default function ECGWave({ lead = "II" }: { lead?: "II" | "V1" }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bufferRef = useRef<number[]>(new Array(WIDTH).fill(0));
  const beatPosRef = useRef(0);
  const rafRef = useRef<number>(0);

  const heartRate = useMonitorStore((s) => s.heartRate);
  const rhythm = useMonitorStore((s) => s.rhythm);
  const waveformSettings = useMonitorStore((s) => s.waveformSettings);
  const ecgLeadOff = useMonitorStore((s) => s.events.ecgLeadOff);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let frame = 0;
    const beatDuration = () => beatDurationFromHR(heartRate, SAMPLE_RATE);

    const draw = () => {
      if (ecgLeadOff) {
        bufferRef.current = new Array(WIDTH).fill(0);
      } else {
        const dur = beatDuration();
        if (beatPosRef.current >= dur) beatPosRef.current = 0;
        const beat = generateBeatSamples(rhythm, dur, waveformSettings.ecgGain);
        const noisy = applyArtifacts(beat, waveformSettings, frame);
        const val = noisy[beatPosRef.current] ?? 0;
        bufferRef.current.push(val);
        bufferRef.current.shift();
        beatPosRef.current += 1;
      }

      ctx.clearRect(0, 0, WIDTH, HEIGHT);
      ctx.strokeStyle = "#22c55e";
      ctx.lineWidth = 2;
      ctx.beginPath();
      bufferRef.current.forEach((v, i) => {
        const x = i;
        const y = HEIGHT / 2 - v * (HEIGHT / 2.5);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      frame++;
      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, [heartRate, rhythm, waveformSettings, ecgLeadOff]);

  return (
    <div className="w-full">
      <div className="flex justify-between text-xs text-green-400 px-1">
        <span>{lead} x1 {rhythm === "NSR" ? "ST" : ""}</span>
        <span>ECG</span>
      </div>
      <canvas
        ref={canvasRef}
        width={WIDTH}
        height={HEIGHT}
        className="w-full bg-black rounded"
      />
    </div>
  );
}

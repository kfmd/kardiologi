"use client";

import { useEffect, useRef } from "react";
import { useMonitorStore } from "@/store/useMonitorStore";
import { generatePlethBeat, beatDurationFromHR } from "@/lib/waveformEngine";

const SAMPLE_RATE = 100;
const WIDTH = 800;
const HEIGHT = 100;

export default function PlethWave() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bufferRef = useRef<number[]>(new Array(WIDTH).fill(0));
  const beatPosRef = useRef(0);
  const rafRef = useRef<number>(0);

  const heartRate = useMonitorStore((s) => s.heartRate);
  const perfusionIndex = useMonitorStore((s) => s.perfusionIndex);
  const amplitude = useMonitorStore((s) => s.waveformSettings.plethAmplitude);
  const probeRemoved = useMonitorStore((s) => s.events.spo2ProbeRemoved);
  const motionArtifact = useMonitorStore((s) => s.events.motionArtifact);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = () => {
      if (probeRemoved) {
        bufferRef.current = new Array(WIDTH).fill(0);
      } else {
        const dur = beatDurationFromHR(heartRate, SAMPLE_RATE);
        if (beatPosRef.current >= dur) beatPosRef.current = 0;
        const beat = generatePlethBeat(dur, amplitude, perfusionIndex);
        let val = beat[beatPosRef.current] ?? 0;
        if (motionArtifact) val += (Math.random() - 0.5) * 0.4;
        bufferRef.current.push(val);
        bufferRef.current.shift();
        beatPosRef.current += 1;
      }

      ctx.clearRect(0, 0, WIDTH, HEIGHT);
      ctx.strokeStyle = "#22d3ee";
      ctx.lineWidth = 2;
      ctx.beginPath();
      bufferRef.current.forEach((v, i) => {
        const y = HEIGHT - 10 - v * (HEIGHT - 20);
        if (i === 0) ctx.moveTo(i, y);
        else ctx.lineTo(i, y);
      });
      ctx.stroke();

      rafRef.current = requestAnimationFrame(draw);
    };
    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, [heartRate, perfusionIndex, amplitude, probeRemoved, motionArtifact]);

  return (
    <div className="w-full">
      <div className="flex justify-between text-xs text-cyan-400 px-1">
        <span>Pleth</span>
        <span>SpO2 %</span>
      </div>
      <canvas ref={canvasRef} width={WIDTH} height={HEIGHT} className="w-full bg-black rounded" />
    </div>
  );
}
